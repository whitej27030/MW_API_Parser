# Available imports for MW_API_Parser
# v1.0.1

from .mw_api_response import MW_Response

from .def_audio_links import Build_Audio_Links

from .get_def_html import Get_Def_HTML

from .get_def_original import Get_Def_Original

from .get_def_plain_text import Get_Def_Plain_Text
